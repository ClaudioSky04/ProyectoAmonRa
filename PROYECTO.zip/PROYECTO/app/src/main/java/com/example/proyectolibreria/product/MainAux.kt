package com.example.proyectolibreria.product

import com.example.proyectolibreria.entities.Product

interface MainAux {
    fun getProductSelected(): Product?
}