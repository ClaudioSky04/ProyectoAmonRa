package com.example.proyectolibreria.entities

class EventPost() {
    var isSuccess: Boolean = false
    var documentId: String? = null
    var photoUrl: String = ""
}