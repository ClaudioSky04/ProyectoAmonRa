package com.example.proyectolibreria.chat

import com.example.proyectolibreria.entities.Message

interface OnChatListener {
    fun deleteMessage(message: Message)
}