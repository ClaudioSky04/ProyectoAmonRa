package com.example.proyectolibreria.product

import com.example.proyectolibreria.entities.Product

interface OnProductListener {
    fun onClick(product: Product)
    fun onLongClick(product: Product)
}