package com.example.proyectolibreria.order

import com.example.proyectolibreria.entities.Order

interface OrderAux {
    fun getOrderSelected(): Order
}