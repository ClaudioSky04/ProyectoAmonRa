package com.example.cliente_libreria.order

import com.example.cliente_libreria.entities.Order

interface OrderAux {
    fun getOrderSelected(): Order
}