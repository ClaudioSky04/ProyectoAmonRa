package com.example.cliente_libreria.order

import com.example.cliente_libreria.entities.Order

interface OnOrderListener {
    fun onTrack(order: Order)
    fun onStartChat(order: Order)
}