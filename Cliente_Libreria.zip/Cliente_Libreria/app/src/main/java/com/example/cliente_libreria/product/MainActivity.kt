package com.example.cliente_libreria.product

import android.content.Intent
import android.content.pm.PackageManager
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.provider.ContactsContract
import android.util.Base64
import android.util.Log
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.core.content.edit
import androidx.preference.PreferenceManager
import androidx.recyclerview.widget.GridLayoutManager
import com.example.cliente_libreria.Constants
import com.example.cliente_libreria.R
import com.example.cliente_libreria.cart.CartFragment
import com.example.cliente_libreria.databinding.ActivityMainBinding
import com.example.cliente_libreria.detail.DetailFragment
import com.example.cliente_libreria.entities.Product
import com.example.cliente_libreria.order.OrderActivity
import com.example.cliente_libreria.profile.ProfileFragment
import com.firebase.ui.auth.AuthMethodPickerLayout
import com.firebase.ui.auth.AuthUI
import com.firebase.ui.auth.ErrorCodes
import com.firebase.ui.auth.IdpResponse
import com.google.firebase.auth.FirebaseAuth
import com.google.firebase.auth.FirebaseUser
import com.google.firebase.firestore.DocumentChange
import com.google.firebase.firestore.FirebaseFirestore
import com.google.firebase.firestore.ListenerRegistration
import com.google.firebase.firestore.Query
import com.google.firebase.messaging.FirebaseMessaging
import java.security.MessageDigest

class MainActivity : AppCompatActivity() , OnProductListener, MainAux{

    private lateinit var binding: ActivityMainBinding

    private lateinit var firebaseAuth: FirebaseAuth
    private lateinit var authStateListener: FirebaseAuth.AuthStateListener

    private lateinit var adapter: ProductAdapter

    private lateinit var firestoreListener: ListenerRegistration
    private var queryPagination: Query? = null

    private  var productSelected: Product? = null

    private val productCartList = mutableListOf<Product>()

    private val resultLauncher = registerForActivityResult(ActivityResultContracts.StartActivityForResult()){
        val response = IdpResponse.fromResultIntent(it.data)

        if(it.resultCode == RESULT_OK){
            val user = FirebaseAuth.getInstance().currentUser
            if (user != null){
                Toast.makeText(this,"Bienvenido", Toast.LENGTH_LONG).show()

                val preferences = PreferenceManager.getDefaultSharedPreferences(this)
                val token = preferences.getString(Constants.PROP_TOKEN, null)

                token?.let {
                    val db = FirebaseFirestore.getInstance()
                    val tokenMap = hashMapOf(Pair(Constants.PROP_TOKEN, token))

                    db.collection(Constants.COLL_USERS)
                        .document(user.uid)
                        .collection(Constants.COLL_TOKENS)
                        .add(tokenMap)
                        .addOnSuccessListener {
                            Log.i("registered token", token)
                            preferences.edit {
                                putString(Constants.PROP_TOKEN, null)
                                    .apply()
                            }
                        }
                        .addOnFailureListener() {
                            Log.i("no registered token", token)
                        }
                }
            }
        } else {
            if (response == null) {
                Toast.makeText(this,"Hasta Pronto", Toast.LENGTH_LONG).show()
                finish()
            } else {
                response.error?.let {
                    if (it.errorCode == ErrorCodes.NO_NETWORK){
                        Toast.makeText(this,"Sin red", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(this,"Codigo de error: ${it.errorCode}",
                            Toast.LENGTH_LONG).show()
                    }
                }
            }
        }
    }


    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        configAuth()
        configRecyclerView()
        configButtons()
    }

    private fun configAuth(){
        firebaseAuth = FirebaseAuth.getInstance()
        authStateListener = FirebaseAuth.AuthStateListener { auth ->
            if (auth.currentUser != null){
                //supportActionBar?.title = auth.currentUser?.displayName
                updateTitle(auth.currentUser!!)
                binding.llProgress.visibility = View.GONE
                binding.nsvProducts.visibility = View.VISIBLE
            } else {
                val providers = arrayListOf(
                    AuthUI.IdpConfig.EmailBuilder().build(),
                    AuthUI.IdpConfig.GoogleBuilder().build(),
                    AuthUI.IdpConfig.FacebookBuilder().build(),
                    AuthUI.IdpConfig.PhoneBuilder().build())

                /*val loginView = AuthMethodPickerLayout.Builder(R.layout.view_login)
                    //.setEmailButtonId(R.id.btnEmail)
                    //.setGoogleButtonId(R.id.btnGoogle)
                    //.setFacebookButtonId(R.id.btnFacebook)
                    //.setPhoneButtonId(R.id.phone_button)
                    //.setTosAndPrivacyPolicyId(R.id.tvPolicy)
                    .build()*/

                resultLauncher.launch(
                    AuthUI.getInstance()
                        .createSignInIntentBuilder()
                        .setAvailableProviders(providers)
                        .setIsSmartLockEnabled(false)
                        //.setTosAndPrivacyPolicyUrls("https://www.facebook.com/hectorclaudio.ramzes.7/",
                          //  "https://www.instagram.com/claudiohector04/?hl=es")
                        //.setAuthMethodPickerLayout(loginView)
                        .build())

            }
        }

        try {
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.P) {
                val info = getPackageManager().getPackageInfo(
                    "com.example.cliente_libreria",
                    PackageManager.GET_SIGNING_CERTIFICATES)
                for (signature in info.signingInfo.apkContentsSigners) {
                    val md = MessageDigest.getInstance("SHA");
                    md.update(signature.toByteArray());
                    Log.d("API >= 28 KeyHash:",
                        Base64.encodeToString(md.digest(), Base64.DEFAULT));
                }
            } else {
                val info = getPackageManager().getPackageInfo(
                    "com.example.cliente_libreria",
                    PackageManager.GET_SIGNATURES);
                for (signature in info.signatures) {
                    val md = MessageDigest.getInstance("SHA");
                    md.update(signature.toByteArray());
                    Log.d("API < 28 KeyHash:",
                        Base64.encodeToString(md.digest(), Base64.DEFAULT));
                }
            }
        } catch (e: Exception) {
            e.printStackTrace()
        }

    }

    override fun onResume() {
        super.onResume()
        firebaseAuth.addAuthStateListener(authStateListener)
        configFirestoreRealtime()
    }

    override fun onPause() {
        super.onPause()
        firebaseAuth.removeAuthStateListener(authStateListener)
        firestoreListener.remove()
    }

    private fun configRecyclerView(){
        adapter = ProductAdapter(mutableListOf(Product()), this)
        binding.recyclerView.apply {
            layoutManager = GridLayoutManager(this@MainActivity,3,
                GridLayoutManager.HORIZONTAL, false)
            adapter = this@MainActivity.adapter
        }
    }

    private fun configButtons(){
        binding.btnViewCart.setOnClickListener{
            val fragment = CartFragment()
            fragment.show(supportFragmentManager.beginTransaction(), CartFragment::class.java.simpleName)
        }
    }

    override fun onCreateOptionsMenu(menu: Menu?): Boolean {
        menuInflater.inflate(R.menu.menu_main, menu)
        return super.onCreateOptionsMenu(menu)
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when(item.itemId){
            R.id.action_sign_out -> {
                AuthUI.getInstance().signOut(this)
                    .addOnSuccessListener {
                        Toast.makeText(this,"Sesion Terminada",Toast.LENGTH_LONG).show()
                    }
                    .addOnCompleteListener {
                        if(it.isSuccessful){
                            binding.nsvProducts.visibility = View.GONE
                            binding.llProgress.visibility = View.VISIBLE
                        } else {
                            Toast.makeText(this,"No se pudo cerrar la sesion",Toast.LENGTH_SHORT).show()
                        }
                    }
            }
            R.id.action_order_history -> startActivity(Intent(this, OrderActivity::class.java))

            R.id.action_profile -> {
                val fragment = ProfileFragment()
                supportFragmentManager
                    .beginTransaction()
                    .add(R.id.containerMain, fragment)
                    .addToBackStack(null)
                    .commit()

                showButton(false)
            }
        }
        return super.onOptionsItemSelected(item)
    }

    private fun configFirestoreRealtime(){
        val db = FirebaseFirestore.getInstance()
        val productRef = db.collection(Constants.COLL_PRODUCTS)

        firestoreListener = productRef
            .limit(6)
            .addSnapshotListener{snapshots, error ->
            if (error != null){
                Toast.makeText(this,"Error al consultar datos.  ",Toast.LENGTH_SHORT).show()
                return@addSnapshotListener
            }
                snapshots?.let { items ->
                    val lastItem = items.documents[items.size() -1]
                    queryPagination = productRef
                        .startAfter(lastItem)
                        .limit(6)

                    for (snapshot in snapshots!!.documentChanges){
                        val product = snapshot.document.toObject(Product::class.java)
                        product.id = snapshot.document.id
                        when(snapshot.type){
                            DocumentChange.Type.ADDED -> adapter.add(product)
                            DocumentChange.Type.MODIFIED -> adapter.update(product)
                            DocumentChange.Type.REMOVED -> adapter.delete(product)
                        }
                    }
                }
            }
    }

    override fun onClick(product: Product) {
        val index = productCartList.indexOf(product)
        if (index != -1){
            productSelected = productCartList[index]
        } else {
            productSelected = product

        }

        val fragment = DetailFragment()
        supportFragmentManager
            .beginTransaction()
            .add(R.id.containerMain, fragment)
            .addToBackStack(null)
            .commit()

        showButton(false)
    }

    override fun getProductsCart(): MutableList<Product> = productCartList


    override fun getProductSelected(): Product? = productSelected

    override fun showButton(isVisible: Boolean) {
        binding.btnViewCart.visibility = if (isVisible) View.VISIBLE else View.GONE
    }

    override fun addProductToCart(product: Product) {
        val index = productCartList.indexOf(product)
        if (index != -1){
            productCartList.set(index, product)
        } else {
            productCartList.add(product)
        }
        updateTotal()
    }

    override fun updateTotal() {
        var total = 0
        productCartList.forEach{ product ->
            total += product.totalPrice()
        }

        if (total == 0){
            binding.tvTotal.text = getString(R.string.product_empty_car)
        } else {
            binding.tvTotal.text = getString(R.string.product_empty_car)
        }
    }

    override fun clearCart() {
        productCartList.clear()
    }

    override fun updateTitle(user: FirebaseUser) {
        supportActionBar?.title = user.displayName
    }


    override fun loadMore() {
        val db = FirebaseFirestore.getInstance()
        val productRef = db.collection(Constants.COLL_PRODUCTS)

        queryPagination?.let {
            it.addSnapshotListener{snapshots, error ->
                if (error != null){
                    Toast.makeText(this,"Error al consultar datos.  ",Toast.LENGTH_SHORT).show()
                    return@addSnapshotListener
                }
                snapshots?.let { items ->
                    val lastItem = items.documents[items.size() -1]
                    queryPagination = productRef
                        .startAfter(lastItem)
                        .limit(6)

                    for (snapshot in snapshots!!.documentChanges){
                        val product = snapshot.document.toObject(Product::class.java)
                        product.id = snapshot.document.id
                        when(snapshot.type){
                            DocumentChange.Type.ADDED -> adapter.add(product)
                            DocumentChange.Type.MODIFIED -> adapter.update(product)
                            DocumentChange.Type.REMOVED -> adapter.delete(product)
                        }
                    }
                }
            }
        }

    }
}