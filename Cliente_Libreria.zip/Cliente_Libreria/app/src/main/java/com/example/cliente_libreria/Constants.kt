package com.example.cliente_libreria

object Constants {
    const val COLL_PRODUCTS = "products"
    const val COLL_REQUESTS = "requests"
    const val COLL_USERS = "users"
    const val COLL_TOKENS = "tokens"
    // Realtime Database
    const val PATH_CHATS = "chats"
    // FCM
    const val PROP_TOKEN = "token"

    const val PROP_DATE = "date"
    const val PROP_CLIENT_ID = "clientId"
    const val PROP_STATUS = "status"
    const val PRO_QUANTITY = "quantity"
}