package com.example.cliente_libreria.product

import com.example.cliente_libreria.entities.Product

interface OnProductListener {
    fun onClick(product: Product)
    fun loadMore()
}