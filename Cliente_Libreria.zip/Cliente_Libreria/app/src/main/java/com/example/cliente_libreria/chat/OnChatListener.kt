package com.example.cliente_libreria.chat

import com.example.cliente_libreria.entities.Message

interface OnChatListener {
    fun deleteMessage(message: Message)
}